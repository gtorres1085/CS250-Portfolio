CS 250 Module Three - Developing Basic ListView Control

Contents:
- src/TopFiveDestinationList.java
- resources/*.png
- SNHUTravelTopFiveDestinations.jar

How to run:
1. Double-click SNHUTravelTopFiveDestinations.jar, or
2. Run: java -jar SNHUTravelTopFiveDestinations.jar

Notes:
- The application displays five destinations in order from most popular to fifth.
- Each list item includes a destination name, one-sentence description, image, and a clickable package button.
- The app also includes extra customizations: a color theme, header section, and custom card-style list renderer.
- The image files were created as original stylized graphics for this project.
