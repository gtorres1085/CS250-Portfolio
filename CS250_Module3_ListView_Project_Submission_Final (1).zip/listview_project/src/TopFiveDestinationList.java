import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.net.URI;
import java.util.Arrays;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultListCellRenderer;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListCellRenderer;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;

/**
 * CS 250 Module Three - Developing Basic ListView Control Assignment.
 *
 * This customized Swing application fulfills the Product Owner user story for
 * the SNHU Travel project by displaying a Top Five Destination List with:
 *  - destination name
 *  - short one-sentence description
 *  - destination image
 *  - clickable package link button for each location
 *
 * Extra customizations added:
 *  - themed color palette
 *  - custom card-style list renderer
 *  - header/instruction section
 *
 * Image note:
 * The five destination images in the resources folder are based on real place
 * photos sourced from Wikimedia Commons. A credit file is included in the
 * project folder so the image creators are acknowledged clearly.
 */
public class TopFiveDestinationList {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            UIManager.put("List.selectionBackground", new Color(217, 232, 255));
            UIManager.put("List.selectionForeground", new Color(24, 42, 73));

            TopDestinationListFrame frame = new TopDestinationListFrame();
            frame.setVisible(true);
        });
    }
}

/**
 * Main application window that displays the top five destinations.
 */
class TopDestinationListFrame extends JFrame {
    private static final long serialVersionUID = 1L;

    private final DefaultListModel<Destination> listModel = new DefaultListModel<>();
    private final JList<Destination> destinationList = new JList<>(listModel);

    public TopDestinationListFrame() {
        super("SNHU Travel - Top Five Destination List");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1020, 760);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(12, 12));

        // Customized color scheme to make the interface feel more polished.
        Color pageBackground = new Color(244, 248, 252);
        Color headerBackground = new Color(24, 42, 73);
        Color accentGold = new Color(213, 172, 85);

        getContentPane().setBackground(pageBackground);

        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(new BoxLayout(headerPanel, BoxLayout.Y_AXIS));
        headerPanel.setBackground(headerBackground);
        headerPanel.setBorder(new EmptyBorder(18, 22, 18, 22));

        JLabel titleLabel = new JLabel("SNHU Travel | Top Five Destinations");
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 26));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel subtitleLabel = new JLabel(
            "Click a package button to view a sample top-selling travel package for that destination.");
        subtitleLabel.setFont(new Font("SansSerif", Font.PLAIN, 15));
        subtitleLabel.setForeground(new Color(225, 232, 245));
        subtitleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel noteLabel = new JLabel("Ordered from the most popular destination to number five.");
        noteLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
        noteLabel.setForeground(accentGold);
        noteLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        headerPanel.add(titleLabel);
        headerPanel.add(Box.createVerticalStrut(6));
        headerPanel.add(subtitleLabel);
        headerPanel.add(Box.createVerticalStrut(8));
        headerPanel.add(noteLabel);

        add(headerPanel, BorderLayout.NORTH);

        // Populate the list in priority order from most popular to fifth-most popular.
        buildDestinationList();

        destinationList.setCellRenderer(new DestinationCellRenderer());
        destinationList.setFixedCellHeight(180);
        destinationList.setBackground(pageBackground);
        destinationList.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scrollPane = new JScrollPane(destinationList);
        scrollPane.setBorder(new EmptyBorder(10, 12, 12, 12));
        scrollPane.getViewport().setBackground(pageBackground);
        add(scrollPane, BorderLayout.CENTER);

        JLabel footerLabel = new JLabel(
            "Created for CS 250 Module Three. Destination photo credits are listed in IMAGE_CREDITS.txt.",
            SwingConstants.CENTER);
        footerLabel.setFont(new Font("SansSerif", Font.ITALIC, 12));
        footerLabel.setBorder(new EmptyBorder(0, 0, 12, 0));
        footerLabel.setForeground(new Color(88, 101, 122));
        add(footerLabel, BorderLayout.SOUTH);
    }

    /**
     * Adds the five destinations to the list model.
     */
    private void buildDestinationList() {
        List<Destination> destinations = Arrays.asList(
            new Destination(
                1,
                "Paris, France",
                "Paris blends iconic landmarks, art, dining, and walkable neighborhoods into a world-class city escape.",
                "/resources/paris.png",
                "https://www.expedia.com/Paris.d179898.Destination-Travel-Guides"),
            new Destination(
                2,
                "Tokyo, Japan",
                "Tokyo offers an exciting mix of modern entertainment, amazing food, and historic cultural sites in one city.",
                "/resources/tokyo.png",
                "https://www.expedia.com/Tokyo.d179900.Destination-Travel-Guides"),
            new Destination(
                3,
                "New York City, USA",
                "New York City gives travelers famous attractions, nonstop energy, and unforgettable skyline views year-round.",
                "/resources/new_york_city.png",
                "https://www.expedia.com/New-York.d178293.Destination-Travel-Guides"),
            new Destination(
                4,
                "Rome, Italy",
                "Rome delivers ancient history, memorable architecture, and authentic Italian cuisine in a timeless setting.",
                "/resources/rome.png",
                "https://www.expedia.com/Rome.d179899.Destination-Travel-Guides"),
            new Destination(
                5,
                "Cancun, Mexico",
                "Cancun is a relaxing beach destination known for sunny weather, turquoise water, and resort-style vacations.",
                "/resources/cancun.png",
                "https://www.expedia.com/Cancun.d179995.Destination-Travel-Guides")
        );

        for (Destination destination : destinations) {
            listModel.addElement(destination);
        }
    }
}

/**
 * Simple data model to keep each destination's information together.
 */
class Destination {
    private final int rank;
    private final String name;
    private final String description;
    private final String imagePath;
    private final String packageUrl;

    public Destination(int rank, String name, String description, String imagePath, String packageUrl) {
        this.rank = rank;
        this.name = name;
        this.description = description;
        this.imagePath = imagePath;
        this.packageUrl = packageUrl;
    }

    public int getRank() {
        return rank;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getImagePath() {
        return imagePath;
    }

    public String getPackageUrl() {
        return packageUrl;
    }
}

/**
 * Custom renderer that turns each list row into a styled travel card.
 */
class DestinationCellRenderer implements ListCellRenderer<Destination> {
    @Override
    public Component getListCellRendererComponent(JList<? extends Destination> list,
                                                  Destination value,
                                                  int index,
                                                  boolean isSelected,
                                                  boolean cellHasFocus) {
        JPanel card = new JPanel(new BorderLayout(14, 0));
        card.setOpaque(true);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(isSelected ? new Color(52, 104, 194) : new Color(207, 216, 228), 2),
            new EmptyBorder(12, 12, 12, 12)));
        card.setBackground(isSelected ? new Color(235, 242, 255) : Color.WHITE);
        card.setPreferredSize(new Dimension(920, 170));

        JLabel imageLabel = new JLabel(loadAndScaleIcon(value.getImagePath(), 260, 150));
        imageLabel.setBorder(BorderFactory.createLineBorder(new Color(220, 225, 233), 1));
        card.add(imageLabel, BorderLayout.WEST);

        JPanel textPanel = new JPanel();
        textPanel.setLayout(new BoxLayout(textPanel, BoxLayout.Y_AXIS));
        textPanel.setOpaque(false);

        JLabel rankLabel = new JLabel("#" + value.getRank() + " Most Popular Destination");
        rankLabel.setFont(new Font("SansSerif", Font.BOLD, 15));
        rankLabel.setForeground(new Color(161, 118, 17));
        rankLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel nameLabel = new JLabel(value.getName());
        nameLabel.setFont(new Font("SansSerif", Font.BOLD, 22));
        nameLabel.setForeground(new Color(24, 42, 73));
        nameLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel descriptionLabel = new JLabel("<html><div style='width:430px; line-height:1.45;'>" +
            value.getDescription() + "</div></html>");
        descriptionLabel.setFont(new Font("SansSerif", Font.PLAIN, 15));
        descriptionLabel.setForeground(new Color(65, 73, 89));
        descriptionLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JButton packageButton = new JButton("View Top-Selling Package");
        packageButton.setAlignmentX(Component.LEFT_ALIGNMENT);
        packageButton.setFocusable(false);
        packageButton.setBackground(new Color(24, 42, 73));
        packageButton.setForeground(Color.WHITE);
        packageButton.setFont(new Font("SansSerif", Font.BOLD, 13));
        packageButton.setToolTipText(value.getPackageUrl());

        // Clicking the button opens the travel package link in the system browser.
        packageButton.addActionListener(e -> openLink(value.getPackageUrl()));

        JLabel linkLabel = new JLabel("<html><u>Package link:</u> " + value.getPackageUrl() + "</html>");
        linkLabel.setFont(new Font("SansSerif", Font.PLAIN, 12));
        linkLabel.setForeground(new Color(72, 89, 117));
        linkLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        textPanel.add(rankLabel);
        textPanel.add(Box.createVerticalStrut(4));
        textPanel.add(nameLabel);
        textPanel.add(Box.createVerticalStrut(8));
        textPanel.add(descriptionLabel);
        textPanel.add(Box.createVerticalStrut(10));

        JPanel buttonWrap = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        buttonWrap.setOpaque(false);
        buttonWrap.add(packageButton);
        buttonWrap.setAlignmentX(Component.LEFT_ALIGNMENT);

        textPanel.add(buttonWrap);
        textPanel.add(Box.createVerticalStrut(6));
        textPanel.add(linkLabel);

        card.add(textPanel, BorderLayout.CENTER);
        return card;
    }

    /**
     * Loads and scales images so they display consistently inside the list rows.
     */
    private ImageIcon loadAndScaleIcon(String imagePath, int width, int height) {
        java.net.URL imageUrl = getClass().getResource(imagePath);
        if (imageUrl == null) {
            return new ImageIcon();
        }
        ImageIcon icon = new ImageIcon(imageUrl);
        Image scaledImage = icon.getImage().getScaledInstance(width, height, Image.SCALE_SMOOTH);
        return new ImageIcon(scaledImage);
    }

    /**
     * Opens a web link in the default system browser. If browsing is unavailable,
     * a message box displays the link so the user can still copy it.
     */
    private void openLink(String url) {
        try {
            if (Desktop.isDesktopSupported()) {
                Desktop.getDesktop().browse(new URI(url));
            } else {
                throw new UnsupportedOperationException("Desktop browsing is not supported on this system.");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null,
                "Unable to open the browser automatically. Use this link:\n" + url,
                "Travel Package Link",
                JOptionPane.INFORMATION_MESSAGE);
        }
    }
}
